import { createContext, useEffect, useState } from "react";
import { createCardRequest, createTableRequest, createBoardTableRequest, getBoardsRequest, getTablesRequest, /*addFrontPageRequest*/ addDateToCardRequest, addMemberOnCardRequest, cardSecondaryInfoRequest, addActivityCardRequest } from "../api/boardsRequest";
import { loginRequest, signInRequest } from "../api/credentialsRequest";

const TableContext = createContext();

export const TableContextProvider = ({children}) => {

    const [credentials, setCredentials] = useState([]);
    const [userContent, setUserContent] = useState([]);

    const signInContext = async (signInObj) => {
        await signInRequest(signInObj);
    }

    useEffect(() => {
        setCredentials(JSON.parse(localStorage.getItem('cred')));
    }, [])

    const loginContext = async (credentialsObj) => {
        const res = await loginRequest(credentialsObj);

        if(res){
            console.log("Login successfull");
            localStorage.clear();
            localStorage.setItem('cred', JSON.stringify(res.data));
            setCredentials(JSON.parse(localStorage.getItem('cred')));
        }else{
            console.log("El usuario no existe");
        }
    }

    const getBoardsContext = async (sessionId) => {
        const res = await getBoardsRequest("658eea91d6a1c930df58afa0")
        setUserContent(res.data);
    }
    
    const getTablesContext = async (sessionId, boardId) => {
        const res = await getTablesRequest(sessionId, boardId)
        console.log("res: ", res.data);
        setUserContent(res.data);
    }
    /*const addFrontPageContext = async () => {
        const res = await addFrontPageRequest()
        console.log(res.data);
    }*/
    const addDateToCardContext = async () => {
        const res = await addDateToCardRequest()
        console.log(res.data);
    }
    const addMemberOnCardContext = async () => {
        const res = await addMemberOnCardRequest()
        console.log(res.data);
    }

    const createBoardTableContext = async (sessionId, boardTablesTitle, backColor, boardLink, acces) => {
        const takeColor = backColor.substring(1);
        await createBoardTableRequest(sessionId, boardTablesTitle, takeColor, boardLink, acces);
    }

    const createTableContext = async (createTableObj) => {
        const res = await createTableRequest(createTableObj);
        setUserContent(res.data);
    }

    const createCardContext = async (createCardObj) => {
        await createCardRequest(createCardObj);
    }

    const cardSecondaryInfoContext = async (cardSecondaryInfoObj) => {
        const res = await cardSecondaryInfoRequest(cardSecondaryInfoObj)
    }

    const saveActivityContext = async (activityCardObj) => {
        addActivityCardRequest(activityCardObj);
    }

    return(
        <TableContext.Provider value={{
            credentials, 
            setCredentials, 
            userContent, 
            setUserContent, 
            signInContext, 
            loginContext, 
            getBoardsContext, 
            getTablesContext, 
            //addFrontPageContext, 
            addDateToCardContext, 
            addMemberOnCardContext, 
            createTableContext, 
            createCardContext, 
            createBoardTableContext,
            cardSecondaryInfoContext, 
            saveActivityContext}}>{children}</TableContext.Provider>
    )
}

export default TableContext;