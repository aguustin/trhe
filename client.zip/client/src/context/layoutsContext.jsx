import { createContext, useState } from "react"

const LayoutsContext = createContext();

export const LayoutsContextProvider = ({children}) => {

    const [changePage, setChangePage] = useState(false);
    const [addList, setAddList] = useState(false);

    return(
        <LayoutsContext.Provider value={{changePage, setChangePage, addList, setAddList}}>{children}</LayoutsContext.Provider>
    )
}

export default LayoutsContext;