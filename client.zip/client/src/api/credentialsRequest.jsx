import axios from "axios";

export const signInRequest = (signInObj) => axios.post('http://localhost:4000/signIn', signInObj);

export const loginRequest = (credentialsObj) => axios.post('http://localhost:4000/userAuthentication', credentialsObj);