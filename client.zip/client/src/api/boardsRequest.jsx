import axios from "axios";

export const getBoardsRequest = (sessionId) => axios.get(`http://localhost:4000/boardTables/${sessionId}`);

export const getTablesRequest = (sessionId, boardId) => axios.get(`http://localhost:4000/getTablesByBoard/${sessionId}/${boardId}`, console.log(sessionId, " ", boardId));

export const createBoardTableRequest = async (sessionId, boardTablesTitle, backColor, boardLink, acces) => await axios.put(`http://localhost:4000/createBoard/${sessionId}/${boardTablesTitle}/${backColor}/${boardLink}/${acces}`);
                        
export const createTableRequest = (createTableObj) => axios.post(`http://localhost:4000/createTable`, createTableObj);

export const createCardRequest = (createCardObj) => axios.put(`http://localhost:4000/createCard/${createCardObj.sessionId}/${createCardObj.boardId}/${createCardObj.tableId}/${createCardObj.cardTitle}`);

//export const addFrontPageRequest = (addFronPageObj) =>  axios.put(`http://localhost:4000/addFrontPage/${addFronPageObj.sessionId}/${addFronPageObj.boardId}/${addFronPageObj.tableId}/${addFronPageObj.cardId}/${addFronPageObj.frontPage}`);

export const addDateToCardRequest = (addDateObj) => axios.put(`http://localhost:4000/${addDateObj.sessionId}/${addDateObj.boardId}/${addDateObj.tableId}/${addDateObj.cardId}/${addDateObj.cardDate}`);

export const addMemberOnCardRequest = (memberObj) => axios.put(`http://localhost:4000/${memberObj.sessionId}/${memberObj.boardId}/${memberObj.tableId}/${memberObj.cardId}/${memberObj.username}/${memberObj.userProfile}/${memberObj.userMail}`);

export const cardSecondaryInfoRequest = async (cardSecondaryInfoObj) => {
    const form = new FormData();

    for(let key in cardSecondaryInfoObj) {
        form.append(key, cardSecondaryInfoObj[key]);
        console.log(cardSecondaryInfoObj[key]);
    }
    console.log("form: ", form);
    await axios.post('http://localhost:4000/cardInfo', form, {
        headers: {
            'Content-Type':'multipart/form-data'
        }
    });
}


//export const cardSecondaryInfoRequest = (cardSecondaryInfoObj) => axios.put(`http://localhost:4000/cardInfo/${cardSecondaryInfoObj.sessionId}/${cardSecondaryInfoObj.boardId}/${cardSecondaryInfoObj.tableId}/${cardSecondaryInfoObj.cardId}/${cardSecondaryInfoObj.frontPage}/${cardSecondaryInfoObj.cardDescription}`); //seguir con esto

export const addActivityCardRequest = (activityObj) => axios.put(`http://localhost:4000/activityCard/${activityObj.sessionId}/${activityObj.boardId}/${activityObj.tableId}/${activityObj.cardId}/${activityObj.memberName}/${activityObj.memberComment}`);

export const getAllTablesRequest = () => axios.get(`http://localhost:4000/getAllTables`);
