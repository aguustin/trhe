import './nav.css';
import progress from '../../assets/progress.png';
import person from '../../assets/person.png';
import user from '../../assets/user.png';
import setting from '../../assets/setting.png';
import { useContext, useState } from 'react';
import TableContext from '../../context/tableContext';

const Nav = () => {

    const {credentials, loginContext, signInContext} = useContext(TableContext)
    const [openCredentials, setOpenCredentials] = useState(false);
    const [openCredentialsConfiguration, setOpenCredentialsConfiguration] = useState(false);
    const [openLogin, setOpenLogin] = useState(false);
    const [openSignInForm, setOpenSignInForm] = useState(false);

    const signIn = (e) => {
        e.preventDefault();
        const email = e.target.elements.email.value;
        const username = e.target.elements.username.value;
        const password = e.target.elements.password.value;
        const confirmPassword = e.target.elements.confirmPassword.value;
      
        if(password === confirmPassword){
            const signInObj = {
                email: email,
                username: username,
                password: password,
                confirmPassword: confirmPassword
            }
            signInContext(signInObj);
        }else{
            alert("las contraseñas no coinciden");
        }   

    }

    const logout = () => {

    }

    const login = (e) => {
        e.preventDefault();
        const email = e.target.elements.email.value;
        const password = e.target.elements.password.value;
        const credentialsObj = {
            email: email,
            password: password
        }
        loginContext(credentialsObj);
    }

    return(
        <>
            <nav className='nav'>
                <img className='title-img' src={progress} alt=""></img>
                <h1>TRHE</h1>
                <div className='nav-buttons'>
                    <div>
                        <button className='nav-list'><p>Marcado</p></button>
                        <img src="" alt=""></img>
                    </div>
                    <div>
                        <button className='nav-list'><p>Plantillas</p></button>
                        <img src="" alt=""></img>
                    </div>
                    <div>
                        <button className='create-button'><p>Crear</p></button>
                        <img src="" alt=""></img>
                    </div>
                </div>
                <div className='search-profile-div'>
                    <input type="text" placeholder='Buscar' name="search"></input>
                    <button className='profile-button' onClick={() => setOpenCredentials(!openCredentials)}>AM</button>
                </div>
                {openCredentials ? <div className='credentials'>
                     <div>
                        <img src={user} alt=""></img><label>Agustín Molé</label>
                    </div>
                    <div>
                        <img src={setting} alt=""></img><button onClick={() => setOpenCredentialsConfiguration(!openCredentialsConfiguration)}><p>Configuración</p></button>
                    </div>
                    <div><button onClick={() => logout()}><p>Cerrar session</p></button></div> 
                </div> : 
                <div className='credentials-ing'>
                    <img src={person} alt=""></img><button onClick={() => setOpenLogin(!openLogin)}><p>Ingresar</p></button>
                </div>}                
            </nav>
            { openLogin && <>
            { openSignInForm ? <>
            <div className='form-login-blackout' onClick={() => setOpenLogin(false)}></div>
                <form className='form-login' onSubmit={(e) => signIn(e)}>
                    <h4>Sign your account</h4>
                    <div className='form-login-group'>
                        <label htmlFor='email' className='form-login-label'>Email</label>
                        <input type="text" placeholder='Enter email...' className='i' name="email"></input>
                    </div>
                    <div className='form-login-group'>
                        <label htmlFor='username' className='form-login-label'>Username</label>
                        <input type="text" placeholder='type your nick...' className='i' name="username"></input>
                    </div>
                    <div className='form-login-group'>
                        <label htmlFor='password' className='form-login-label'>Password</label>
                        <input type="password" placeholder='Enter your password...' className='i' name="password"></input>
                    </div>
                    <div className='form-login-group'>
                        <label htmlFor='confirmPassword' className='form-login-label'>Confirm password</label>
                        <input type="password" placeholder='Confirm your password...' className='i' name="confirmPassword"></input>
                    </div>
                    <div className='login-buttons'>
                        <button type="submit">Sign In</button>
                        <button>Cancel</button>
                        <button onClick={() => setOpenSignInForm(false)} id='changeFormLogin'>you have an account? Login</button>
                    </div>
                </form>
            </>
            : 
            <>
             <div className='form-login-blackout' onClick={() => setOpenLogin(false)}></div>
                <form className='form-login' onSubmit={(e) => login(e)}>
                    <h4>Enter your account</h4>
                    <div className='form-login-group'>
                        <label htmlFor='email' className='form-login-label'>Email</label>
                        <input type="text" placeholder='Enter email...' className='i' name="email"></input>
                    </div>
                    <div className='form-login-group'>
                        <label htmlFor='password' className='form-login-label'>Password</label>
                        <input type="password" placeholder='Enter your password...' className='i' name="password"></input>
                    </div>
                    <div className='login-buttons'>
                        <button type="submit">Sign In</button>
                        <button>Cancel</button>
                        <button onClick={() => setOpenSignInForm(true)} id='changeFormLogin'>Login</button>
                    </div>
                </form>
            </>}
            </>}
            </>
    )
}

export default Nav;