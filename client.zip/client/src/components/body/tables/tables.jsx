import './tables.css';
import boardTables from '../../../assets/boardTables.png';
import group from '../../../assets/group.png';
import setting from '../../../assets/setting.png';
import table from '../../../assets/table.png';
import calendar from '../../../assets/calendar.png';
import prueba from '../../../assets/koku.jpg';
import clock from '../../../assets/clock.png';
import close from '../../../assets/close.png';
import clips from '../../../assets/clip.png';
import desc from '../../../assets/text.png';
import items from '../../../assets/items.png';
import { useContext, useState } from 'react';
import LayoutsContext from '../../../context/layoutsContext';
import TableContext from '../../../context/tableContext';

const Tables = () => {

    const {setChangePage, addList, setAddList} = useContext(LayoutsContext);
    const {credentials, createTableContext, userContent, createCardContext, cardSecondaryInfoContext, saveActivityContext} = useContext(TableContext);
    const [openCardOptions, setOpenCardOptions] = useState(false);
    const [openTextDescArea, setOpenTextDescArea] = useState(false);
    const [openTextActivityArea, setOpenTextActivityArea] = useState(false);
    const [openAttachmentForm, setOpenAttachmentForm] = useState(false);
    const [setAddCardLayout, addCardLayout ] = useState(false);
    const [descriptionCard, setDescriptionCard] = useState([]);
    const [cardProps, setCardProps] = useState([]);
    const [activityCard, setActivityCard] = useState([]);
    const [imageCard, setImageCard] = useState([]);

    
    const openBoardTables = () => {
        setChangePage(false);
    }

    const createTable = async (e) => {
        e.preventDefault();
        const tableTitle = e.target.elements.tableTitle.value;
        const createTableObj = {
            sessionId: credentials[0]._id,
            boardId: userContent[0].boardTables[0]._id,
            tableTitle: tableTitle,
        }
        await createTableContext(createTableObj);
    }

    const cardOptionsProps = (boardId, tableId, cardId) => {
        setOpenCardOptions(true);
        setCardProps([boardId, tableId, cardId]);
    }
    console.log("cardProps: ", cardProps);

    const saveActivity = (e) => {
        e.preventDefault();
        console.log("cardProps", cardProps);

        const activityCardObj = {
            sessionId: credentials[0]._id,
            boardId: cardProps[0],
            tableId: cardProps[1],
            cardId: cardProps[2],
            memberName: credentials[0].username,
            memberComment: activityCard
        }
        console.log(activityCardObj);
        saveActivityContext(activityCardObj);
    }

    const addMember = () => {

    }

    const addDate = () => {

    }
    const addFrontPage = () => {

    }
    const addAttachments = () => {

    }

    const createCard = (e, sessionId, boardId, tableId) => {
        e.preventDefault();
        const cardTitle = e.target.elements.cardTitle.value;

        const createCardObj = {
            sessionId: sessionId,
            boardId: boardId,
            tableId: tableId,
            cardTitle: cardTitle,
        }

        createCardContext(createCardObj);
    }

    const saveCardSecondaryInfo = (e, sessionId, boardId, tableId, cardId) => {  //seguir con esto
        e.preventDefault();
        const cardSecondaryInfoObj = {
            sessionId: sessionId,
            boardId: boardId, 
            tableId: tableId, 
            cardId: cardId,
            frontPage: imageCard,
            cardDescription: descriptionCard,
        }

        cardSecondaryInfoContext(cardSecondaryInfoObj);
        console.log("cardSecondaryInfoObj: ", cardSecondaryInfoObj);  //crear la funcion en el context
    }

    console.log("userContent: ", userContent);

    return(
        <>
        <div className='tables'>
            <div className='tables-sideNav'>
                <div className='tables-sideNav-first'>
                    <button className='E'>E</button>
                    <label>Espacio de trabajo de Trello</label>
                </div>
                <div className='tables-sideNav-second'>
                    <button><img src={boardTables} alt=""></img><p>Tableros</p></button>
                    <button><img src={group} alt=""></img><p>Miembros</p></button>
                    <button><img src={setting} alt=""></img><label>Ajustes del Espacio de trabajo</label></button>
                </div>
                <div className='tables-sideNav-third'>
                    <label>Vistas del Espacio de trabajo</label>
                    <button><img src={table} alt=""></img><p>Tabla</p></button>
                    <button><img src={calendar} alt=""></img><p>Calendario</p></button>
                </div>
                <div className='tables-sideNav-four'>
                    <label>Sus tableros</label>
                    <button><div></div><p>mi tablero</p></button>
                </div>
            </div>





            {openCardOptions && 
            <>
            <div className='card-options' onClick={() => setOpenCardOptions(false)}></div>
                <div className='card-options-body'>
                    <div className='card-tit-act-desc'>
                        <div className='card-options-section'>
                            <img className='icon-imgs' src={table} alt=""></img>
                            <div>
                                <h4>titulo carta</h4>
                                <p>En la lista organizar A</p>
                            </div>
                        </div>
                        <div className='card-options-section'>
                            <img className='icon-imgs' src={desc} alt=""></img>
                            <div>
                                <div className='card-option'>
                                    <h4>Descripción</h4>
                                    <button onClick={() => setOpenTextDescArea(!openTextDescArea)}>Editar</button>
                                </div>
                                {openTextDescArea && 
                                <form className='card-textarea'>
                                    <textarea rows={8} onChange={(e) => setDescriptionCard(e.target.value)}></textarea>
                                    {/*<div className='card-options-buttons-sc'>
                                        <button>Guardar</button>
                                        <button className='cancel'>Cancelar</button>
                                    </div>*/}
                                </form>}
                            </div>
                        </div>
                        <div className='card-options-section card-option-attachment'>
                            <img className='icon-imgs' src={clips} alt=""></img>
                            <div>
                                <div className='card-option'>
                                    <h4>Adjuntos</h4>
                                    <button onClick={() => setOpenAttachmentForm(!openAttachmentForm)}>Editar</button>
                                </div>
                                {openAttachmentForm && <form className='attachmentForm' encType='multipart/form-data'>
                                    <button type="button" className='attachment-button'>
                                        <input name="cardImage" type="file" id="attachmentInput" onChange={(e) => setImageCard(e.target.files[0])}/>
                                    </button>
                                </form>}
                            </div>
                        </div>
                        <div className='card-options-section'>
                            <img className='icon-imgs' src={items} alt=""></img>
                            <div>
                                <div className='card-option'>
                                    <h4>Actividad</h4>
                                    <button onClick={() => setOpenTextActivityArea(!openTextActivityArea)}>Editar</button>
                                </div>
                                {openTextActivityArea && 
                                <form className='card-textarea' onSubmit={(e) => saveActivity(e)}>
                                    <textarea rows={8} onChange={(e) => setActivityCard(e.target.value)}></textarea>
                                    {<div className='card-options-buttons-sc'>
                                        <button type='submit'>Guardar</button>
                                        <button className='cancel'>Cancelar</button>
                                    </div>}
                                </form>}
                                <div className='activity-container'>
                                    {userContent?.map((boards) => 
                                    boards.boardTables.map((tables) =>
                                    tables.table.map((cards) =>
                                    cards.card.map((cardInfo) =>
                                    cardInfo.cardActivity.map((activity) =>
                                    <div className='activity-comment'>
                                        <label>{activity.memberName}</label>
                                        <div key={activity._id}>
                                            <p>{activity.memberComment}</p>
                                        </div>
                                    </div>
                                    )))))}
                                </div>
                            </div>
                        </div>
                        <button className='saveCardInfo' onClick={(e) => saveCardSecondaryInfo(e, credentials[0]._id, cardProps[0], cardProps[1], cardProps[2])}>
                            Save
                        </button>
                    </div>


                    <div className='card-sideNav'>
                        <ul>
                            <label>Editar tarjeta</label>
                            <button onClick={() => addMember()}><img src={group} alt=""></img><p>Miembros</p></button>
                            <button onClick={() => addDate()}><img src={clock} alt=""></img><p>Fechas</p></button>
                            <button onClick={() => addFrontPage()}><img src={table} alt=""></img><p>Portada</p></button>
                            <button onClick={() => addAttachments()}><img src={clips} alt=""></img><p>Adjunto</p></button>
                        </ul>
                    </div>
                </div>
                </>}







            <div className='cards-body'>
                <div className='cards-navigation'>
                    <button onClick={() => openBoardTables()}><h3>Mi tablero</h3></button>
                    <button>añadir a favoritos</button>
                    <button>Filtros</button>
                    <button className='am'>AM</button>
                </div>
                <div className='cards-table'>
                    <>
                        {userContent?.map((boards) => 
                        boards.boardTables.map((tables) =>
                        tables.table.map((t) =>
                        <div className='card'>
                            <div className='card-title'><label>{t.tableTitle}</label></div>
                            {t.card.map((card) =>
                            <div key={card._id}>
                                <div className='card-info' onClick={() => cardOptionsProps(tables._id, t._id, card._id)}>
                                    <img src={card?.frontPage} alt=""></img>
                                    <p>{card?.cardTitle}</p>
                                    {card?.cardDate && <div className='card-date'>
                                        <div className='date-img'><img src={clock} alt=""></img><p>{card?.cardDate}</p></div>
                                    </div>}
                                    {card?.cardDescription && <p className='card-desc'>{card?.cardDescription}</p>}
                                </div>
                            </div>)}
                            {addCardLayout ?
                            <>
                                <form className='addCard-form' onSubmit={(e) => createCard(e, credentials[0]._id, tables._id, t._id)}>
                                    <input className='addCard-input' type="text" name="cardTitle" placeholder='Introduzca el titulo de la tarjeta...'></input>
                                    <div>
                                        <button type="submit" id="anadir-lista">Añadir tarjeta</button>
                                        <button onClick={() => setAddCardLayout(false)}><img src={close} alt=""></img></button>
                                    </div>
                                </form> 
                            </>
                            :  
                            <div className='add-card'>
                                <button onClick={() => setAddCardLayout(true)}>Añadir una tarjeta</button>
                            </div>}
                        </div>
                        )))}
                    </>
                        {addList ? 
                        <>
                            <form className='addList-form' onSubmit={(e) => createTable(e)}>
                                <input type="text" name="tableTitle" placeholder='Introduzca el titulo de la lista...'></input>
                                <div>
                                    <button type="submit" id="anadir-lista">Añadir lista</button>
                                    <button onClick={() => setAddList(false)} id="X"><img src={close} alt=""></img></button>
                                </div>
                            </form> 
                        </> 
                        :
                        <div className='add-list'>
                            <button onClick={() => setAddList(true)}>+ Añadir otra lista</button>
                        </div>}
                </div>
            </div>
        </div>
        </>
    )
}

export default Tables;