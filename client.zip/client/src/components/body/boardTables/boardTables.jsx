import './boardTables.css';
import boardTables from '../../../assets/boardTables.png';
import discarded from '../../../assets/discarded.png';
import group from '../../../assets/group.png';
import tables from '../../../assets/tables.png';
import setting from '../../../assets/setting.png';
import koku from '../../../assets/koku.jpg';
import { useContext, useEffect, useState } from 'react';
import LayoutsContext from '../../../context/layoutsContext';
import TableContext from '../../../context/tableContext';

const BoardTables = () => {

    const {changePage, setChangePage} = useContext(LayoutsContext);
    const {credentials, userContent, getBoardsContext, createBoardTableContext, getTablesContext} = useContext(TableContext);
    const [openAddBoard, setOpenAddBoard] = useState(false);
    const [backColor, setBackColor] = useState();

    useEffect(() => {
        getBoardsContext(credentials[0]?._id);
    }, [credentials]);

    const openBoard = (e, boardId) => {
        e.preventDefault();
        getTablesContext(credentials[0]?._id, boardId); //quedo acaaa
        setChangePage(true);
    }

    const createBoard = (e) => {
        e.preventDefault();
        setOpenAddBoard(false);
        const sessionId = credentials[0]._id;
        const boardTablesTitle = e.target.elements.boardTablesTitle.value;
        const boardLink = crypto.randomUUID();
        const acces = 'public';
        createBoardTableContext(sessionId, boardTablesTitle, backColor, boardLink, acces);
    }

    return(
        <>
            <div className='boardTables'>
                <div className='boardTables-sideNav'>
                    <div className='boardTables-sideNav-first'>
                        <button><img src={boardTables} alt=""></img><p>Plantillas</p></button>
                        <button><img src={tables} alt=""></img><p>Tableros</p></button>
                    </div>
                    <div className='boardTables-sideNav-second'>
                        <label>Espacios de trabajo</label>
                        <ul>
                            <li><button><img src={tables} alt =""></img><p>Tableros</p></button></li>
                            <li><button><img src={discarded} alt =""></img><p>Lo mas destacado</p></button></li>
                            <li><button><img src={group} alt =""></img><p>Miembros</p></button></li>
                            <li><button><img src={setting} alt =""></img><p>Configuracion</p></button></li>
                        </ul>
                    </div>
                </div>
                <div className='boardTables-body'>
                    <div>
                        <h3>TUS ESPACIOS DE TRABAJO</h3>
                    </div>
                    <div className='boardTables-options'>
                        <div className='boardTable-category'>
                            <div>E</div>
                            <label>Espacio de trabajo de trello</label>
                        </div>
                        <button><img src={tables} alt=""></img><p>Tableros</p></button>
                        <button><img src={group} alt=""></img><p>Miembros (1)</p></button>
                        <button><img src={setting} alt=""></img><p>Configuración</p></button>
                    </div>
                    <div className='boards'>
                        {userContent?.map((boards) => 
                        boards.boardTables?.map((b) =>
                        <button className='selectBoards' style={{backgroundColor: '#' + b.boardTableBackground}} onClick={(e) => openBoard(e, b._id)}><p>{b.boardTablesTitle}</p></button>
                        ))}
                        <button id='add-board' onClick={() => setOpenAddBoard(true)}><p>Agregar tablero</p></button>
                        {openAddBoard && 
                        <div className='create-board'>
                            <div className='crear-tablero'>
                                <label>Crear tablero</label>
                                <button onClick={() => setOpenAddBoard(false)}>X</button>
                            </div>
                            <div className='create-board-background'>
                                <img src={koku} alt=""></img>
                            </div>
                            <form onSubmit={(e) => createBoard(e)}>
                                <div className='select-background'>
                                    <button type="button" onClick={(e) => setBackColor(e.target.value)} name="backColor" value="#228cd5" style={{backgroundColor:"#228cd5"}}></button>
                                    <button type="button" onClick={(e) => setBackColor(e.target.value)} name="backColor" value="#0b50af" style={{backgroundColor:"#0b50af"}}></button>
                                    <button type="button" onClick={(e) => setBackColor(e.target.value)} name="backColor" value="#6742af" style={{backgroundColor:"#6742af"}}></button>
                                    <button type="button" onClick={(e) => setBackColor(e.target.value)} name="backColor" value="#a869c1" style={{backgroundColor:"#a869c1"}}></button>
                                    <button type="button" onClick={(e) => setBackColor(e.target.value)} name="backColor" value="#ef763a" style={{backgroundColor:"#ef763a"}}></button>
                                </div>
                                <div className='board-title'>
                                    <label>Titulo del tablero*</label>
                                    <input type='text' name="boardTablesTitle"></input>
                                    <button type='submit'>Crear</button>
                                </div>
                            </form>
                        </div>}
                    </div>
                </div>
            </div>
        </>
    )
}

export default BoardTables;