import { useContext } from "react";
import BoardTables from "./boardTables/boardTables";
import Tables from "./tables/tables";
import LayoutsContext from "../../context/layoutsContext";

const Body = () => {
    const {changePage} = useContext(LayoutsContext);
    return(
        <>
            <div className="body">
                {changePage ? <Tables/> : <BoardTables/>}
            </div>
        </>
    )
}

export default Body;