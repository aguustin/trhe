import './App.css';
import Body from './components/body/body';
import Nav from './components/nav/nav';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LayoutsContextProvider } from './context/layoutsContext';
import { TableContextProvider } from './context/tableContext';

function App() {
  return (
    <div className="App">
      <LayoutsContextProvider>
      <TableContextProvider>
        <Nav/>
        <BrowserRouter>
            <div className='side-body'>
              <Routes>
                    <Route path="/" element={<Body/>} />
              </Routes>
            </div>
        </BrowserRouter>
      </TableContextProvider>
      </LayoutsContextProvider>
    </div>
  );
}

export default App;